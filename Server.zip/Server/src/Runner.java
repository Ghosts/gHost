import gHost.Repository;
import gHost.Server;

class Runner implements Repository {
    public static void main(String[] args) {
        Server server = new Server();
        int port = 80; // Default port
        /*Add Working Directories. */
        /* Directory of resource files (pages, images, scripts, etc.)*/
        /* !Important, make sure you either pass a directory as an argument, or change the "a" variable here. */
        String a = Runner.class.getProtectionDomain().getCodeSource().getLocation().toString();
        a = a.replace("file:","");
        a = a.replace("/out/production/Server/","/resources/");
        directories.put("root", a);
        /* Pages are in my root directory, this is left as blank - no subdirectory needed. */
        directories.put("pages", "");

        /*Set up Routes */
        routes.put("/","index");
        routes.put("/index","index");
        routes.put("/home","index");
        routes.put("/ghost","ghost/index");
        routes.put("/phantom","phantom/index");
        routes.put("/uniquity","uniquity/index");
        routes.put("/mausUpdates","updates.html");
        switch (args.length) {
            /* Two arguments - port and rootDirectory*/
            case 2:
                port = Integer.parseInt(args[0]);
                directories.put("root",args[1]);
                server.startServer(port);
                break;
            default:
                server.startServer(port);
        }
    }
}
